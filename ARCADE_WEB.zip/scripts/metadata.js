define(function(){
    return {
        pageGroups: [{"id":"4cf962de-98e3-a61d-9819-931ca8e42dbc","name":"Default group","pages":[{"id":"e4ca9759-e526-50cf-b816-369161f89fd9","name":"HOME"},{"id":"cc834441-b9df-fc9c-83cd-53b17f934ed6","name":"RANKING"},{"id":"2384e2f9-97e1-2323-0f87-197f45a17cc3","name":"FORO"},{"id":"4799895f-299b-08c2-b17b-ffe75cc4761c","name":"Juego"}]}],
        downloadLink: "//services.ninjamock.com/html/htmlExport/download?shareCode=8LNJFWx&projectName=Untitled project",
        startupPageId: 0,

        forEachPage: function(func, thisArg){
        	for (var i = 0, l = this.pageGroups.length; i < l; ++i){
                var group = this.pageGroups[i];
                for (var j = 0, k = group.pages.length; j < k; ++j){
                    var page = group.pages[j];
                    if (func.call(thisArg, page) === false){
                    	return;
                    }
                }
            }
        },
        findPageById: function(pageId){
        	var result;
        	this.forEachPage(function(page){
        		if (page.id === pageId){
        			result = page;
        			return false;
        		}
        	});
        	return result;
        }
    }
});
